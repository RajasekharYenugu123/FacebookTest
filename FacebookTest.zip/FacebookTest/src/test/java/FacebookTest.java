

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.time.Duration;




public class FacebookTest {
    public WebDriver driver;

    @BeforeMethod
    public void setup() {
        // Setting up driver instance
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Rajasekhar\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("https://www.facebook.com/");
    }


    @Test(priority = 1)
    public void verifyLoginPageOpens() {
        // Step 1: Check URL
        String currentUrl = driver.getCurrentUrl();
        Assert.assertEquals(currentUrl, "https://www.facebook.com/", "URL should be Facebook login page URL.");

        // Step 2: Check for email and password fields
        WebElement emailField = driver.findElement(By.id("email"));
        WebElement passwordField = driver.findElement(By.id("pass"));
        WebElement loginButton = driver.findElement(By.name("login"));

        // Step 3: Verify email, password fields, and login button are displayed
        Assert.assertTrue(emailField.isDisplayed(), "Email field should be displayed on the login page.");
        Assert.assertTrue(passwordField.isDisplayed(), "Password field should be displayed on the login page.");
        Assert.assertTrue(loginButton.isDisplayed(), "Login button should be displayed on the login page.");
    }

    @Test(priority = 2)
    public void verifyFacebookLogoIsPresent() {
        // Step 1: Locate the Facebook logo using CSS Selector
        WebElement logo = driver.findElement(By.cssSelector("img[alt='Facebook']"));

        // Step 2: Verify the logo is displayed on the page
        Assert.assertTrue(logo.isDisplayed(), "Facebook logo should be visible on the login page.");
    }


    @Test(priority = 3)
    public void verifyFacebookLogoProperties() {
        WebElement logo = driver.findElement(By.cssSelector("img[alt='Facebook']"));
        String color = logo.getCssValue("color");

        System.out.println("Actual logo color: " + color);  // For debugging

        // Update the color value if confirmed to be accurate
        Assert.assertEquals(color, "rgba(28, 30, 33, 1)", "Logo color should be the expected shade.");
    }



    @Test(priority = 4)
    public void testLoginButton() {
        try {
            WebElement loginButton = driver.findElement(By.name("login"));
            Assert.assertTrue(loginButton.isDisplayed(), "Login button is not displayed");
        } catch (org.openqa.selenium.NoSuchElementException e) {
            System.out.println("Login button element not found: " + e.getMessage());
        }
    }

    @Test(priority = 5)

    public void LoginValidEmailValidPassword() {
        // Locate the email input field and enter the valid email
        WebElement emailField = driver.findElement(By.id("email"));
        emailField.sendKeys("rajasekhar.now123@gmail.com");

        // Locate the password input field and enter the valid password
        WebElement passwordField = driver.findElement(By.id("pass"));
        passwordField.sendKeys("Rajasekhar@123");

        // Locate the login button and click it
        WebElement loginButton = driver.findElement(By.name("login"));
        loginButton.click();

        String expectedUrl = "https://www.facebook.com/";

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.urlToBe(expectedUrl));

        String currentUrl = driver.getCurrentUrl();
        Assert.assertEquals(expectedUrl, currentUrl, "Urls do not match");
    }

    @Test(priority = 6)
    public void LoginValidEmailInvalidPassword() {
        // Locate the email input field and enter the valid email
        WebElement emailField = driver.findElement(By.id("email"));
        emailField.sendKeys("rajasekhar.now123@gmail.com");

        // Locate the password input field and enter an invalid password
        WebElement passwordField = driver.findElement(By.id("pass"));
        passwordField.sendKeys("InvalidPassword123");

        // Locate the login button and click it
        WebElement loginButton = driver.findElement(By.name("login"));
        loginButton.click();

        // Wait and check for an error message or the absence of redirect to the homepage
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        WebElement errorMessageEl = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div._9ay7")));
        // Verify that the error message is displayed
        Assert.assertTrue(errorMessageEl.isDisplayed(), "Error message should be displayed for invalid password.");

        // Optionally verify the URL did not change to the homepage
        String unexpectedUrl = "https://www.facebook.com/";
        String currentUrl = driver.getCurrentUrl();
        Assert.assertNotEquals(currentUrl, unexpectedUrl, "User should not be redirected to the homepage.");
    }


    @Test(priority = 7)
    public void LoginInvalidEmailValidPassword() {
        // Locate the email input field and enter an invalid email format
        WebElement emailField = driver.findElement(By.id("email"));
        emailField.sendKeys("rajasekhar.now12345@gmail.co ");

        // Locate the password input field and enter the valid password
        WebElement passwordField = driver.findElement(By.id("pass"));
        passwordField.sendKeys("Rajasekhar@123");

        // Locate the login button and click it
        WebElement loginButton = driver.findElement(By.name("login"));
        loginButton.click();

        // Wait and check for an error message indicating an invalid email or failure to log in
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement errorMessageEl = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div._9ay7")));

        // Verify that the error message is displayed
        Assert.assertTrue(errorMessageEl.isDisplayed(), "Error message should be displayed for invalid email.");

        // Optionally verify that the user is not redirected to the homepage
        String unexpectedUrl = "https://www.facebook.com/";
        String currentUrl = driver.getCurrentUrl();
        Assert.assertNotEquals(currentUrl, unexpectedUrl, "User should not be redirected to the homepage with an invalid email.");
    }


    @Test(priority = 8)
    public void testInvalidEmailInvalidPassword() {

        WebElement emailField = driver.findElement(By.id("email"));
        emailField.sendKeys("rajasekhar.now1234@gmail.com"); // Invalid email format

        // Locate the password input field and enter an invalid password
        WebElement passwordField = driver.findElement(By.id("pass"));
        passwordField.sendKeys("Rajasekhar@1234");

        // Locate the login button and click it
        WebElement loginButton = driver.findElement(By.name("login"));
        loginButton.click();

        // Wait and check for an error message indicating login failure due to invalid credentials
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement errorMessage = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div._9ay7")));

        // Verify that the error message is displayed
        Assert.assertTrue(errorMessage.isDisplayed(), "Error message should be displayed for invalid email and password.");

        // Optionally verify that the user is not redirected to the homepage
        String unexpectedUrl = "https://www.facebook.com/";
        String currentUrl = driver.getCurrentUrl();
        Assert.assertNotEquals(currentUrl, unexpectedUrl, "User should not be redirected to the homepage with invalid credentials.");
    }


    @Test(priority = 9)
    public void testInvalidOrValidEmailWithBlankPassword() {
        // Locate the email input field and enter a valid or invalid email
        WebElement emailField = driver.findElement(By.id("email"));
        emailField.sendKeys("rajasekhar.now123@gmail.com");

        // Leave the password field blank
        WebElement passwordField = driver.findElement(By.id("pass"));
        passwordField.sendKeys("");

        // Locate the login button and click it
        WebElement loginButton = driver.findElement(By.name("login"));
        loginButton.click();

        // Wait and check for an error message indicating that the password is required
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement errorMessage = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div._9ay7")));

        // Verify that the error message is displayed
        Assert.assertTrue(errorMessage.isDisplayed(), "Error message should be displayed when the password is blank.");

        // Optionally, verify that the user is not redirected to the homepage
        String unexpectedUrl = "https://www.facebook.com/";
        String currentUrl = driver.getCurrentUrl();
        Assert.assertNotEquals(currentUrl, unexpectedUrl, "User should not be redirected to the homepage with a blank password.");
    }


    @Test(priority = 10)
    public void testBlankEmailWithAnyPassword() {
        // Leave the email field blank
        WebElement emailField = driver.findElement(By.id("email"));
        emailField.sendKeys("");

        // Locate the password input field and enter a valid or invalid password
        WebElement passwordField = driver.findElement(By.id("pass"));
        passwordField.sendKeys("Rajasekhar@123"); // Use a valid or invalid password

        // Locate the login button and click it
        WebElement loginButton = driver.findElement(By.name("login"));
        loginButton.click();

        // Wait for the error message indicating that the email is required
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement errorMessage = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div._9ay7")));

        // Verify that the error message is displayed
        Assert.assertTrue(errorMessage.isDisplayed(), "Error message should appear when email is blank.");

        // Verify that the user is not redirected to the homepage
        String unexpectedUrl = "https://www.facebook.com/";
        String currentUrl = driver.getCurrentUrl();
        Assert.assertNotEquals(currentUrl, unexpectedUrl, "User should not be redirected to homepage with blank email.");
    }


    @Test(priority = 11)
    public void loginWithEmptyFields() {
        try {
            // Attempt to submit the login form
            WebElement loginButtonEl = driver.findElement(By.name("login"));
            loginButtonEl.submit();

            // Wait for the error message to appear
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));

            // Check if the error message is present
            try {
                WebElement errorMessageEl = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("_9ay7")));
                String errorMessage = errorMessageEl.getText();
                Assert.assertEquals(errorMessage, "The email address or mobile number you entered isn't connected to an account. Find your account and log in.");
            } catch (org.openqa.selenium.TimeoutException e) {
                System.out.println("Error message did not appear, indicating login may have been successful or unexpected behavior.");
            }

        } catch (org.openqa.selenium.NoSuchElementException e) {
            System.out.println("Element not found: " + e.getMessage());
        }
    }


    @Test(priority = 12)
    public void testValidPhoneNumberValidPassword() {
        // Locate the phone input field and enter a valid phone number
        WebElement phoneField = driver.findElement(By.id("email"));
        phoneField.sendKeys("9912887123"); // Replace with a valid phone number

        // Locate the password input field and enter a valid password
        WebElement passwordField = driver.findElement(By.id("pass"));
        passwordField.sendKeys("Rajasekhar@123");

        // Locate the login button and click it
        WebElement loginButton = driver.findElement(By.name("login"));
        loginButton.click();

        String expectedUrl = "https://www.facebook.com/";

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.urlToBe(expectedUrl));

        String currentUrl = driver.getCurrentUrl();
        Assert.assertEquals(currentUrl, expectedUrl, "User should be redirected to the homepage after a successful login.");
    }

    @Test(priority = 13)
    public void testValidPhoneNumberInvalidPassword() {
        // Locate the phone input field and enter a valid phone number
        WebElement phoneField = driver.findElement(By.id("email"));
        phoneField.sendKeys("9912887123"); // Replace with a valid phone number

        // Locate the password input field and enter an invalid password
        WebElement passwordField = driver.findElement(By.id("pass"));
        passwordField.sendKeys("Rajasekhar@1234");

        // Locate the login button and click it
        WebElement loginButton = driver.findElement(By.name("login"));
        loginButton.click();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement errorMessageEl = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div._9ay7")));

        Assert.assertTrue(errorMessageEl.isDisplayed(), "Error message should be displayed for an invalid password.");
    }


    @Test(priority = 14)
    public void testInvalidPhoneNumberValidPassword() {
        // Locate the phone input field and enter an invalid phone number
        WebElement phoneField = driver.findElement(By.id("email"));
        phoneField.sendKeys("9912887124");

        // Locate the password input field and enter a valid password
        WebElement passwordField = driver.findElement(By.id("pass"));
        passwordField.sendKeys("Rajasekhar@123");

        // Locate the login button and click it
        WebElement loginButton = driver.findElement(By.name("login"));
        loginButton.click();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement errorMessageEl = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div._9ay7")));

        Assert.assertTrue(errorMessageEl.isDisplayed(), "Error message should be displayed for an invalid phone number.");
    }

    @Test(priority = 15)
    public void testInvalidPhoneNumberInvalidPassword() {
        // Locate the phone input field and enter an invalid phone number
        WebElement phoneField = driver.findElement(By.id("email"));
        phoneField.sendKeys("9912887124");

        // Locate the password input field and enter an invalid password
        WebElement passwordField = driver.findElement(By.id("pass"));
        passwordField.sendKeys("Rajasekhar@1234");

        // Locate the login button and click it
        WebElement loginButton = driver.findElement(By.name("login"));
        loginButton.click();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement errorMessageEl = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div._9ay7")));

        Assert.assertTrue(errorMessageEl.isDisplayed(), "Error message should be displayed for an invalid phone number and password.");
    }

    @Test(priority = 16)
    public void testPhoneNumberAndBlankPassword() {
        // Locate the phone input field and enter a valid or invalid phone number
        WebElement phoneField = driver.findElement(By.id("email"));
        phoneField.sendKeys("9912887123"); // Replace with a valid or invalid phone number

        // Leave the password field blank
        WebElement passwordField = driver.findElement(By.id("pass"));
        passwordField.sendKeys("");

        // Locate the login button and click it
        WebElement loginButton = driver.findElement(By.name("login"));
        loginButton.click();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement errorMessageEl = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div._9ay7")));

        Assert.assertTrue(errorMessageEl.isDisplayed(), "Error message should be displayed for a blank password.");
    }


    @Test(priority = 16)
    public void testPhoneNumberAndBlankPassword1() {
        // Locate the phone input field and enter a valid or invalid phone number
        WebElement phoneField = driver.findElement(By.id("email"));
        phoneField.sendKeys("9912887123"); // Replace with a valid or invalid phone number

        // Leave the password field blank
        WebElement passwordField = driver.findElement(By.id("pass"));
        passwordField.sendKeys("");

        // Locate the login button and click it
        WebElement loginButton = driver.findElement(By.name("login"));
        loginButton.click();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement errorMessageEl = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div._9ay7")));

        Assert.assertTrue(errorMessageEl.isDisplayed(), "Error message should be displayed for a blank password.");
    }




    @Test(priority = 17)
    public void testForgottenPassword() {
        // Locate and click the "Forgotten password?" link
        WebElement forgottenPasswordLink = driver.findElement(By.linkText("Forgotten password?"));
        forgottenPasswordLink.click();

        // Wait until the password recovery page loads
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.urlContains("recover"));

        // Verify if we are on the password recovery page
        String currentUrl = driver.getCurrentUrl();
        Assert.assertTrue(currentUrl.contains("recover"), "User should be redirected to the password recovery page.");

        // Optionally, locate the email or phone input field on the recovery page to ensure it's loaded
        WebElement recoveryInputField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("identify_email")));
        Assert.assertTrue(recoveryInputField.isDisplayed(), "Recovery email or phone input should be visible.");
    }

    @Test(priority = 18)
    public void testCreateNewAccount() {
        // Locate and click the "Create New Account" button
        WebElement createAccountButton = driver.findElement(By.linkText("Create new account"));
        createAccountButton.click();

        // Wait until the sign-up form is visible
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement signUpForm = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("reg_box")));

        // Verify that the form is displayed
        Assert.assertTrue(signUpForm.isDisplayed(), "Sign-up form should be visible.");

        // Optionally, verify fields in the sign-up form (like First Name, Last Name, etc.)
        WebElement firstNameField = signUpForm.findElement(By.name("firstname"));
        WebElement lastNameField = signUpForm.findElement(By.name("lastname"));
        WebElement mobileOrEmailField = signUpForm.findElement(By.name("reg_email__"));
        WebElement passwordField = signUpForm.findElement(By.name("reg_passwd__"));

        Assert.assertTrue(firstNameField.isDisplayed(), "First Name field should be visible.");
        Assert.assertTrue(lastNameField.isDisplayed(), "Last Name field should be visible.");
        Assert.assertTrue(mobileOrEmailField.isDisplayed(), "Mobile or Email field should be visible.");
        Assert.assertTrue(passwordField.isDisplayed(), "Password field should be visible.");
    }

    @Test(priority = 19)
    public void FriendsListTest() {
        try {
        // Locate the email input field and enter the valid email
        WebElement emailField = driver.findElement(By.id("email"));
        emailField.sendKeys("rajasekhar.now123@gmail.com");

        // Locate the password input field and enter the valid password
        WebElement passwordField = driver.findElement(By.id("pass"));
        passwordField.sendKeys("Rajasekhar@123");

        // Locate the login button and click it
        WebElement loginButton = driver.findElement(By.name("login"));
        loginButton.click();


         WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
         WebElement friendsListElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".x1lliihq.x6ikm8r.x10wlt62.x1n2onr6")));

    // Step 4: Verify the text and click on the "Friends" list
            if (friendsListElement.getText().contains("Friends (33 online)")) {
        friendsListElement.click();
        System.out.println("Friends list clicked successfully.");
    } else {
        System.out.println("Friends list element not found or text mismatch.");
    }

} catch (Exception e) {
        e.printStackTrace();
        } finally {
        }
        }











    @AfterMethod
    public void teardown() {

        driver.quit();
    }
}